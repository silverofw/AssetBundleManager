﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotFix
{
    public class Class1
    {
        public void Test()
        {
            UnityEngine.Debug.Log("[CARDOOO] HW!");
        }

        public string GetCompanyName()
        {
            return "cardooo.com";
        }
    }
}
